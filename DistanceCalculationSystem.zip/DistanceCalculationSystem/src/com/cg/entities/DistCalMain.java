package com.cg.entities;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;




public class DistCalMain {
	
	public static void main(String[] args) {
		
	
	Scanner sc=new Scanner(System.in);
	
	
	EntityManagerFactory factory = 
			Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	em.getTransaction().begin();
	distanceCalc dis = new distanceCalc();
	
	System.out.println("enter id");
	int id=sc.nextInt();
	dis.setDistance_id(id);
	
	System.out.println("enter source");
	String source=sc.next();
	dis.setSource(source);
	
	System.out.println("enter destination");
	String destination=sc.next();
	dis.setDestination(destination);
	
	System.out.println("enter distance in km");
	double disKm=sc.nextDouble();
	dis.setDis_in_km(disKm);
	
	
	double miles=dis.getDis_in_km()*1.6;
	System.out.println("destination in miles is:"+miles+"miles");
	dis.setDis_in_miles(miles);
	
	em.persist(dis);
	
	
	System.out.println("details are added");
	
	
	em.getTransaction().commit();
	em.close();
	factory.close();
	
	}
}
