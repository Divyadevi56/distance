package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="distance_calculator")
public class distanceCalc implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private double distance_id;
	private String source;
	private String destination;
	private double dis_in_km;
	private double dis_in_miles;
	

	public double getDistance_id() {
		return distance_id;
	}
	public void setDistance_id(double distance_id) {
		this.distance_id = distance_id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public double getDis_in_km() {
		return dis_in_km;
	}
	public void setDis_in_km(double dis_in_km) {
		this.dis_in_km = dis_in_km;
	}
	public double getDis_in_miles() {
		return dis_in_miles;
	}
	public void setDis_in_miles(double dis_in_miles) {
		this.dis_in_miles = dis_in_miles;
	}
	
	
	
	@Override
	public String toString() {
		return "DistanceCalc [distance_id=" + distance_id + ", source=" + source + ", destination=" + destination
				+ ", dis_in_km=" + dis_in_km + ", dis_in_miles=" + dis_in_miles + "]";
	}


}
